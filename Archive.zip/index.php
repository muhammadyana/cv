<!DOCTYPE html>
<html lang="en">
<head>

<!-- Meta -->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />

<!-- Title -->
<title>I'm Muhammad Yana Mulana - Web Developer & Digital Marketing</title>

<!-- Favicons -->
<link rel="shortcut icon" href="assets/img/favicon.png">
<link rel="apple-touch-icon" href="assets/img/favicon_60x60.png">
<link rel="apple-touch-icon" sizes="76x76" href="assets/img/favicon_76x76.png">
<link rel="apple-touch-icon" sizes="120x120" href="assets/img/favicon_120x120.png">
<link rel="apple-touch-icon" sizes="152x152" href="assets/img/favicon_152x152.png">

<!-- Google Web Fonts -->
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700' rel='stylesheet' type='text/css'>

<!-- CSS Styles -->
<link rel="stylesheet" href="assets/css/styles.css" />

<!-- CSS Theme -->
<link rel="stylesheet" id="theme" href="assets/css/themes/theme-green.css" />

</head>

<body class="bg-grey">

<!-- Loader -->
<div id="page-loader" class="bg-white">
	 <svg class="loader" width="65px" height="65px" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg"><circle class="circle" fill="none" stroke-width="3" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg>
</div>
<!-- Loader / End -->

<!-- BG Image -->
<div class="bg-body bg-image zooming">
	<img src="assets/img/photos/bg_manager.jpg" alt="">
</div>

<!-- Header -->
<header id="header" class="bg-primary">

	<!-- Top Bar -->
	<div id="top-bar">
		<div class="container">
			<nav class="menu module left">
				<a href="index.html" class="active">Home</a>
				<a href="blog.html">Blog</a>
				<a href="documentation.html" target="_blank">Docs</a>
			</nav>
			<nav class="language menu module right hidden-xs">
				<span>Language version:</span>
				<a href="#" class="active">English</a>
				<a href="#">Polish</a>
				<a href="#">Spanish</a>
			</nav>
		</div>
	</div>
	
	<!-- Navigation Bar -->
	<div id="nav-bar" class="container">
		<nav>
			<ul id="nav-primary" class="nav nav-primary">
				<li class="icon-link"><a href="#home"><i class="fa fa-home"></i></a></li>
				<li><a href="#about">About</a></li>
				<li><a href="#skills">Skills</a></li>
				<li><a href="#works">Works</a></li>
				<li><a href="#experience">Experience</a></li>
				<li><a href="#references">References</a></li>
				<li><a href="#latest-posts">Latest Posts</a></li>
				<li><a href="#contact">Contact</a></li>
				<li class="icon-link"><a href="#" class="panel-toggle" data-toggle="panel"><span><span></span></span></a></li>
			</ul>
		</nav>

		<div class="mobile-nav clearfix">
			<div class="owner">
				<img src="assets/img/avatars/yana2.jpg" alt="Muhammad Yana Mulyana">
				<span class="name">Yana</span>
			</div>
			<a href="#" class="panel-toggle" data-toggle="panel"><span><span></span></span></a>
		</div>
	</div>

</header>
<!-- Header / End -->

<!-- Content -->
<div id="content" class="container">
		
	<div id="photo">
		<img src="assets/img/avatars/yana2.jpg" alt="">
	</div>

	<div id="sections-wrapper">
			
		<!-- Section -->
		<section id="home" class="bg-white" data-target="local-scroll">
			<div class="section-content">
				<img class="img-circle mb-40 visible-sm visible-xs" src="assets/img/avatars/yanakecil.png" alt="Muhammad Yana Mulyana">
				<h1 class="mb-0">I'm Muhammad Yana Mulyana</h1>
				<h3 class="text-muted"><span class="typing">Web Developer and Digital Marketing</span></h3>
				<hr class="sep-line">

				<div class="row">
					<div class="col-sm-4">
						<dl class="description-2">
							<dt>Born year:</dt>
							<dd>1993</dd>
							<dt>Experience:</dt>
							<dd>+3 years</dd>
						</dl>
					</div>
					<div class="col-sm-4">
						<dl class="description-2">
							<dt>Address:</dt>
							<dd>sadang serang kec Coblong</dd>
							<dt>Phone:</dt>
							<dd><a href="tel://+6285714757247">085714757247</a></dd>
						</dl>
					</div>
					<div class="col-sm-4">
						<dl class="description-2">
							<dt>E-mail:</dt>
							<dd><a href="#">me@muhammadyana.web.id</a></dd>
							<dt>Folow me!</dt>
							<dd>	
								<a href="https://www.facebook.com/muhammadyana" target="blank" class="icon icon-facebook icon-sm icon-circle"><i class="fa fa-facebook"></i></a>
								<a href="https://github.com/muhammadyana" target="blank" class="icon icon-linkedin icon-sm icon-circle"><i class="fa fa-github"></i></a>
								<a href="https://twitter.com/muhammad_yanaa" target="blank" class="icon icon-twitter icon-sm icon-circle"><i class="fa fa-twitter"></i></a>
								<a href="#" target="blank" class="icon icon-google-plus icon-sm icon-circle"><i class="fa fa-google-plus"></i></a>
								<a href="https://linkedin.com/in/muhammadyana" target="blank" class="icon icon-linkedin icon-sm icon-circle"><i class="fa fa-linkedin"></i></a>
							</dd>
						</dl>
					</div>
				</div>
			</div>
			<a href="#works" class="btn btn-section btn-primary">
				<span class="i-before i"><i class="ti-desktop"></i><i class="ti-arrow-down"></i></span>Check my <strong>works</strong>
			</a>
		</section>

		<!-- Section -->
		<section id="about" class="bg-white">
			<div class="section-content">
				<h3 class="text-muted">About me</h3>
				<p class="lead text-lg mb-0">
					Hello! I’m <strong>Muhammad Yana Mulayan</strong>. I am not a smart people who can quickly understands the lesson explained by the teacher. But I am a people who does not easily give up and despair, and i always try and try to learn and do something. I am a student who is active in the technological competition and often follow the technological competition, as INAICTA (Indonesia ICT Award), PKM (Pekan Kreativitas Mahasiswa) and Micorosft imagine cup. I am also a laboratory assistant as well as a teaching assistant in the course of digital systems. 

				</p>
			</div>
		</section>

		<!-- Section -->
		<section id="skills" class="bg-white">
			<div class="section-content">
				<h3 class="text-muted">My Skills</h3>
				<h5 class="mb-5">Adobe Photoshop</h5>
				<div class="progress">
					<div class="progress-bar" role="progressbar" aria-valuenow="80"></div>
				</div>
				<h5 class="mb-5">Sketch</h5>
				<div class="progress">
					<div class="progress-bar" role="progressbar" aria-valuenow="75"></div>
				</div>
				<h5 class="mb-5">HTML/CSS</h5>
				<div class="progress">
					<div class="progress-bar" role="progressbar" aria-valuenow="95"></div>
				</div>
				<h5 class="mb-5">Javascript / jQuery</h5>
				<div class="progress">
					<div class="progress-bar" role="progressbar" aria-valuenow="85"></div>
				</div>
			</div>
		</section>

		<!-- Section -->
		<section id="promo-video" class="section-video dark">
			<div class="section-content">
				<div class="image bg-image"><img src="assets/img/photos/video_frontend.jpg" alt=""></div>
				<h3 class="title">Why me?</h3>
				<a href="https://www.youtube.com/embed/uVju5--RqtY?rel=0&autoplay=1" class="btn-play"></a>
			</div>
		</section>

		<!-- Section -->
		<section id="services" class="bg-white">
			<div class="section-content">
				<h3 class="text-muted">My services</h3>
				<div class="row">
					<div class="col-sm-6">
						<!-- Icon Box -->
						<div class="icon-box icon-box-1 text-center animated" data-animation="zoomIn">
							<span class="icon icon-muted icon-xl"><i class="ti-desktop"></i></span>
							<h3 class="mb-10">Web Design</h3>
							<p class="lead text-muted">Proffesional &amp; effective coding serivices</p>
						</div>
					</div>
					<div class="col-sm-6">
						<!-- Icon Box -->
						<div class="icon-box icon-box-1 text-center animated" data-animation="zoomIn" data-animation-delay="100">
							<span class="icon icon-muted icon-xl"><i class="ti-layers-alt"></i></span>
							<h3 class="mb-10">Front-End Development</h3>
							<p class="lead text-muted">Proffesional &amp; effective coding serivices</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6">
						<!-- Icon Box -->
						<div class="icon-box icon-box-1 text-center animated" data-animation="zoomIn" data-animation-delay="200">
							<span class="icon icon-muted icon-xl"><i class="ti-mobile"></i></span>
							<h3 class="mb-10">Mobile Apps</h3>
							<p class="lead text-muted">Proffesional &amp; effective coding serivices</p>
						</div>
					</div>
					<div class="col-sm-6">
						<!-- Icon Box -->
						<div class="icon-box icon-box-1 text-center animated" data-animation="zoomIn" data-animation-delay="300">
							<span class="icon icon-muted icon-xl"><i class="ti-mouse-alt"></i></span>
							<h3 class="mb-10">Corporate Identity</h3>
							<p class="lead text-muted">Proffesional &amp; effective coding serivices</p>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!-- Section -->
		<section id="pricing" class="bg-white">
			<div class="section-content">
				<h3 class="text-muted">Pricing</h3>
				<div class="row no-padding">
					<div class="col-sm-4">
						<!-- Price Table -->
						<div class="price-table">
							<span class="icon icon-primary"><i class="ti-desktop"></i></span>
							<h3>Basic</h3>
							<span class="price text-primary">$149</span>
							<ul class="list-lined">
								<li><strong>3 templates</strong> per month</li>
								<li><strong>6 months</strong> support</li>
								<li><strong>Free</strong> Updates </li>
							</ul>
							<div class="bottom">
								<a href="#" class="btn btn-primary">Purchase!<span class="i i-after"><i class="ti-shopping-cart"></i><i class="ti-arrow-right"></i></span></a>
							</div>
						</div>
					</div>
					<div class="col-sm-4">
						<!-- Price Table -->
						<div class="price-table featured">
							<span class="icon icon-white"><i class="ti-desktop"></i></span>
							<h3>Optimal</h3>
							<span class="price">$499</span>
							<ul class="list-lined">
								<li><strong>10 templates</strong> per month</li>
								<li><strong>12 months</strong> support</li>
								<li><strong>Free</strong> Updates </li>
							</ul>
							<div class="bottom">
								<a href="#" class="btn btn-white">Purchase!<span class="i i-after"><i class="ti-shopping-cart"></i><i class="ti-arrow-right"></i></span></a>
							</div>
						</div>
					</div>
					<div class="col-sm-4">
						<!-- Price Table -->
						<div class="price-table">
							<span class="icon icon-primary"><i class="ti-desktop"></i></span>
							<h3>Pro</h3>
							<span class="price text-primary">$999</span>
							<ul class="list-lined">
								<li><strong>Unlimited</strong> templates</li>
								<li><strong>Unlimited</strong> support</li>
								<li><strong>Free</strong> Updates</li>
								<li><strong>Free</strong> Photos</li>
							</ul>
							<div class="bottom">
								<a href="#" class="btn btn-primary">Purchase!<span class="i i-after"><i class="ti-shopping-cart"></i><i class="ti-arrow-right"></i></span></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!-- Section -->
		<section id="works" class="bg-white">
			<div class="section-content clearfix">
				<h3 class="text-muted mb-0 pull-left">My works</h3>
				<nav class="filter tabs-wrapper pull-right">
					<ul class="filter-isotope nav nav-tabs" data-filter-list="#works-list">
						<li class="active"><a href="#" data-filter="*">All</a></li>
						<li><a href="#" data-filter=".webdesign">Webdesign</a></li>
						<li><a href="#" data-filter=".development">Development</a></li>
					</ul>
					<span class="selector"></span>
				</nav>
			</div>

			<div class="images-list-wrapper">
				<div id="works-list" class="masonry images-list filter-list row no-padding">
					<div class="masonry-sizer col-md-4 col-sm-6 col-xs-12"></div>
					<div class="masonry-item webdesign col-md-8 col-sm-6 col-xs-12">
						<!-- Media Item -->
						<div class="image-box image-hover bg-black text-center">
							<div class="image">
								<img src="assets/img/works/work01.jpg" alt="">
							</div>
							<div class="hover">
								<a href="#">
									<h5 class="mb-0">The Flower</h5>
									<span class="text-muted">Webdesign</span>
								</a>
								<a href="projects/project-example.html" data-toggle="ajax-modal" class="btn btn-xs btn-white">Case Study <span class="i-after i"><i class="ti-desktop"></i><i class="ti-arrow-right"></i></span></a>
							</div>
						</div>
					</div>
					<div class="masonry-item development col-md-4 col-sm-6 col-xs-12">
						<!-- Media Item -->
						<div class="image-box image-hover bg-black text-center">
							<div class="image">
								<img src="assets/img/works/work02.jpg" alt="">
							</div>
							<div class="hover">
								<a href="#">
									<h5 class="mb-0">The Bridge</h5>
									<span class="text-muted">Corporate Identity</span>
								</a>
								<a href="projects/project-example.html" data-toggle="ajax-modal" class="btn btn-xs btn-white">Case Study <span class="i-after i"><i class="ti-desktop"></i><i class="ti-arrow-right"></i></span></a>
							</div>
						</div>
					</div>
					<div class="masonry-item webdesign col-md-4 col-sm-6 col-xs-12">
						<!-- Media Item -->
						<div class="image-box image-hover bg-black text-center">
							<div class="image">
								<img src="assets/img/works/work03.jpg" alt="">
							</div>
							<div class="hover">
								<a href="#">
									<h5 class="mb-0">Time Beach</h5>
									<span class="text-muted">Webdesign</span>
								</a>
								<a href="projects/project-example.html" data-toggle="ajax-modal" class="btn btn-xs btn-white">Case Study <span class="i-after i"><i class="ti-desktop"></i><i class="ti-arrow-right"></i></span></a>
							</div>
						</div>
					</div>
					<div class="masonry-item corporate-identity col-md-4 col-sm-6 col-xs-12">
						<!-- Media Item -->
						<div class="image-box image-hover bg-black text-center">
							<div class="image">
								<img src="assets/img/works/work04.jpg" alt="">
							</div>
							<div class="hover">
								<a href="#">
									<h5 class="mb-0">The Forest</h5>
									<span class="text-muted">Webdesign / Webdevelopment</span>
								</a>
								<a href="projects/project-example.html" data-toggle="ajax-modal" class="btn btn-xs btn-white">Case Study <span class="i-after i"><i class="ti-desktop"></i><i class="ti-arrow-right"></i></span></a>
							</div>
						</div>
					</div>
					<div class="masonry-item development col-md-8 col-sm-6 col-xs-12">
						<!-- Media Item -->
						<div class="image-box image-hover bg-black text-center">
							<div class="image">
								<img src="assets/img/works/work05.jpg" alt="">
							</div>
							<div class="hover">
								<a href="#">
									<h5 class="mb-0">The Band</h5>
									<span class="text-muted">Webdevelopment</span>
								</a>
								<a href="projects/project-example.html" data-toggle="ajax-modal" class="btn btn-xs btn-white">Case Study <span class="i-after i"><i class="ti-desktop"></i><i class="ti-arrow-right"></i></span></a>
							</div>
						</div>
					</div>
				</div>
				<div class="images-list-hover">
					<div class="content">
					</div>
				</div>
			</div>
		</section>

		<!-- Section -->
		<section id="experience" class="bg-white">
			<div class="section-content">
				<h3 class="text-muted">Education &amp; Jobs</h3>
				<div class="timeline">
					<!-- Event-->
					<div class="timeline-event animated">
						<div class="date"><span>08.2010 - 09.2011</span></div>
						<div class="content">
							<h3>Front-End Developer</h3>
							<span class="caption">Envato, Sydney, Australia</span>
						</div>
					</div>
					<!-- Event-->
					<div class="timeline-event animated">
						<div class="date"><span>08.2010 - 09.2011</span></div>
						<div class="content">
							<img src="assets/img/photos/london.jpg" alt="" class="img-rounded">
							<h3>Webdesigner &amp; Front End Developer</h3>
							<span class="caption">Envato, Sydney, Australia</span>
						</div>
					</div>
					<!-- Event-->
					<div class="timeline-event animated">
						<div class="date"><span>08.2010 - 09.2011</span></div>
						<div class="content">
							<h3>Front-End Developer</h3>
							<span class="caption">Envato, Sydney, Australia</span>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!-- Section -->
		<section id="references" class="bg-white">
			<div class="section-content">
				<h3 class="text-muted">References</h3>
				<div class="masonry row">
					<div class="masonry-sizer col-sm-6 col-xs-12"></div>
					<div class="masonry-item col-sm-6 col-xs-12">
						<!-- Testimonial -->
						<div class="testimonial animated" data-animation="fadeInUp">
							<div class="testimonial-content">
								The most experiences guy I have ever met before. Huge knowledge &amp; really cool personality.
							</div>
							<div class="testimonial-author with-image">
								<img src="assets/img/users/user01.jpg" alt="">
								<div class="name">Johnatan Doe</div>
								<span class="text-muted">XYZ Inc., LA, USA</span>
							</div>
						</div>
					</div>
					<div class="masonry-item col-sm-6 col-xs-12">
						<!-- Testimonial -->
						<div class="testimonial testimonial-primary animated" data-animation="fadeInUp" data-animation-delay="100">
							<div class="testimonial-content">
								Pellentesque et massa sed diam ornare laoreet nec nec turpis. Aenean in magna lobortis, dignissim sem at, tincidunt nunc. Nunc fringilla a tellus in hendrerit. 
							</div>
							<div class="testimonial-author">
								<div class="name">Johnatan Doe</div>
								<span class="text-muted">XYZ Inc., LA, USA</span>
							</div>
						</div>
					</div>
					<div class="masonry-item col-sm-6 col-xs-12">
						<!-- Testimonial -->
						<div class="testimonial testimonial-primary animated" data-animation="fadeInUp" data-animation-delay="200">
							<div class="testimonial-content">
								Pellentesque et massa sed diam ornare laoreet nec nec turpis. Aenean in magna lobortis, dignissim sem at, tincidunt nunc. Nunc fringilla a tellus in hendrerit. 
							</div>
							<div class="testimonial-author">
								<div class="name">Johnatan Doe</div>
								<span class="text-muted">XYZ Inc., LA, USA</span>
							</div>
						</div>
					</div>
					<div class="masonry-item col-sm-6 col-xs-12">
						<!-- Testimonial -->
						<div class="testimonial animated" data-animation="fadeInUp" data-animation-delay="300">
							<div class="testimonial-content">
								The most experiences guy I have ever met before. Huge knowledge &amp; really cool personality.
							</div>
							<div class="testimonial-author with-image">
								<img src="assets/img/users/user01.jpg" alt="">
								<div class="name">Johnatan Doe</div>
								<span class="text-muted">XYZ Inc., LA, USA</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!-- Section -->
		<section id="latest-posts" class="bg-white">
			<div class="section-content">
				<h3 class="text-muted">Latest Posts</h3>
				<div class="masonry row">
					<div class="masonry-sizer col-sm-6 col-xs-12"></div>
					<div class="masonry-item col-sm-6 col-xs-12">
						<!-- Post -->
						<article class="post item">
							<div class="post-image"><img src="assets/img/posts/post01.jpg" alt=""></div>
							<div class="post-content">
								<ul class="post-meta">
									<li><i class="ti-time"></i><span>25 Sep 2015</span></li>
									<li><i class="ti-tag"></i><span><a href="#">Webdesign</a></span></li>
								</ul>
								<h2><a href="blog-post.html">How to organize your work?</a></h2>
								<p>Mauris feugiat dolor lorem, id tempus felis porta eu. Proin bibendum sodales neque non lobortis. Morbi condimentum eu felis vel auctor.</p>
								<a href="blog-post.html" class="more"><span></span></a>
							</div>
						</article>
					</div>
					<div class="masonry-item col-sm-6 col-xs-12">
						<!-- Post -->
						<article class="post item">
							<div class="post-image"><img src="assets/img/posts/post02.jpg" alt=""></div>
							<div class="post-content">
								<ul class="post-meta">
									<li><i class="ti-time"></i><span>25 Sep 2015</span></li>
									<li><i class="ti-tag"></i><span><a href="#">Webdesign</a></span></li>
								</ul>
								<h2><a href="blog-post.html">Best Design Inspirations</a></h2>
								<p>Mauris feugiat dolor lorem, id tempus felis porta eu. Proin bibendum sodales neque non lobortis.</p>
								<a href="blog-post.html" class="more"><span></span></a>
							</div>
						</article>
					</div>
					<div class="masonry-item col-sm-6 col-xs-12">
						<!-- Post -->
						<article class="post item">
							<div class="post-image"><img src="assets/img/posts/post03.jpg" alt=""></div>
							<div class="post-content">
								<ul class="post-meta">
									<li><i class="ti-time"></i><span>25 Sep 2015</span></li>
									<li><i class="ti-tag"></i><span><a href="#">Webdesign</a></span></li>
								</ul>
								<h2><a href="blog-post.html">How to find perfect client?</a></h2>
								<p>Mauris feugiat dolor lorem, id tempus felis porta eu. Proin bibendum sodales neque non lobortis. Morbi condimentum eu felis vel auctor.</p>
								<a href="blog-post.html" class="more"><span></span></a>
							</div>
						</article>
					</div>
					<div class="masonry-item col-sm-6 col-xs-12">
						<!-- Post -->
						<article class="post item">
							<div class="post-content">
								<ul class="post-meta">
									<li><i class="ti-time"></i><span>25 Sep 2015</span></li>
									<li><i class="ti-tag"></i><span><a href="#">Webdesign</a></span></li>
								</ul>
								<h2><a href="blog-post.html">Busy vs Productive person</a></h2>
								<p>Id tempus felis porta eu. Proin bibendum sodales neque non lobortis. Morbi condimentum eu felis vel auctor.</p>
								<a href="blog-post.html" class="more"><span></span></a>
							</div>
						</article>
					</div>
				</div>
				<div class="text-center">
					<a href="blog.html" class="btn btn-primary">Go to my blog <span class="i i-after"><i class="ti-comments"></i><i class="ti-arrow-right"></i></span></a>
				</div>
			</div>
		</section>

		<!-- Section -->
		<section id="contact" class="bg-white">
			<div class="section-content">
				<h3 class="text-muted">Contact me</h3>
				<div class="row">
					<div class="col-sm-6">
						<!-- Icon Box -->
						<div class="icon-box icon-box-2">
							<span class="icon icon-sm icon-circle icon-primary"><i class="fa fa-map-marker"></i></span>
							<div class="icon-box-content">
								<h6 class="text-muted">Address:</h6>
								<address class="text-md mb-0">
								1111-A Nowhere Lane,<br>
								Outta Sight, State 90378,<br>
								USA
								</address>
							</div>
						</div>
						<!-- Icon Box -->
						<div class="icon-box icon-box-2">
							<span class="icon icon-sm icon-circle icon-primary"><i class="fa fa-envelope"></i></span>
							<div class="icon-box-content">
								<h6 class="text-muted">E-mail:</h6>
								<a href="#" class="link-underline text-md">johnathandoe@gmail.com</a>
							</div>
						</div>
						<!-- Icon Box -->
						<div class="icon-box icon-box-2">
							<span class="icon icon-sm icon-circle icon-primary"><i class="fa fa-phone"></i></span>
							<div class="icon-box-content">
								<h6 class="text-muted">Phone:</h6>
								<a href="#" class="text-md">+0(31)1235 567 89</a>
							</div>
						</div>
					</div>
					<div class="col-sm-6">
						<form id="contact-form" class="contact-form validate-form">
							<div class="form-group input-wrapper">
								<input name="name" type="text" class="form-control" required>
								<span class="input-label">Name</span>
							</div>
							<div class="form-group input-wrapper">
								<input name="email" type="email" class="form-control" required>
								<span class="input-label">E-mail</span>
							</div>
							<div class="form-group input-wrapper">
								<textarea name="message" cols="30" rows="4" class="form-control"></textarea>
								<span class="input-label">Message</span>
								<span class="input-line"></span>
							</div>
							<div class="row">
								<div class="col-sm-8 col-sm-push-2">
									<button type="submit" class="btn btn-submit"><span>Send message</span></button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div id="google-map" class="h-300" data-latitude="40.758895" data-longitude="-73.985131"></div>
		</section>

		<!-- Section -->
		<section id="sign-in" class="bg-primary dark">
			<div class="section-content">
				<h3><strong>Sign up to my newsletter!</strong></h3>
				<form action="//suelo.us12.list-manage.com/subscribe/post-json?u=ed47dbfe167d906f2bc46a01b&amp;id=24ac8a22ad" id="sign-in-form" class="sign-in-form validate-form" method="POST">
					<div class="form-group input-wrapper">
	            		<input class="hidden" type="text" name="b_ed47dbfe167d906f2bc46a01b_24ac8a22ad" tabindex="-1" value="">
						<input type="email" value="" name="EMAIL" class="form-control input-lg" id="mce-EMAIL" required>
						<span class="input-label">Your e-mail</span>
					</div>
					<div class="row">
						<div class="col-sm-6 col-sm-push-3">
							<button type="submit" class="btn btn-submit btn-white"><span>Sign in!</span></button>
						</div>
					</div>
				</form>
			</div>
		</section>


	</div>

</div>
<!-- Content / End -->

<!-- Share -->
<div id="share-it">
	<a href="#" class="icon icon-circle icon-share"><i class="fa fa-share-alt"></i></a>
	<ul class="share-list">
		<li><a href="#" class="icon icon-circle icon-google-plus"><i class="fa fa-google-plus"></i></a></li>
		<li><a href="#" class="icon icon-circle icon-twitter"><i class="fa fa-twitter"></i></a></li>
		<li><a href="#" class="icon icon-circle icon-facebook"><i class="fa fa-facebook"></i></a></li>
	</ul>
</div>

<!-- Panel -->
<nav id="panel" class="bg-white">
	<div class="panel-wrapper">
		<!-- Photo -->
		<div class="photo">
			<img src="assets/img/avatars/yana.jpg" alt="">
		</div>

		<!-- Menu -->
		<div class="menu widget">
			<h6>Navigation</h6>
			<ul id="nav-mobile" class="nav nav-panel">
				<li><a href="#home"><i class="ti-home"></i>Home</a></li>
				<li><a href="#about"><i class="ti-comment-alt"></i>About</a></li>
				<li><a href="#skills"><i class="ti-stats-up"></i>Skills</a></li>
				<li><a href="#works"><i class="ti-heart"></i>Works</a></li>
				<li><a href="#experience"><i class="ti-time"></i>Experience</a></li>
				<li><a href="#references"><i class="ti-file"></i>References</a></li>
				<li><a href="#latest-posts"><i class="ti-comments"></i>Latest Posts</a></li>
				<li><a href="#contact"><i class="ti-mobile"></i>Contact</a></li>
			</ul>
		</div>

		<!-- Latest Posts -->
		<div class="latest-posts widget">
			<h6>Latest Posts</h6>
			<ul class="list-posts">
				<li>
					<a href="#" class="post-image"><img src="assets/img/posts/post01.jpg" alt=""></a>
					<div class="post-content">
						<a href="#">Crazy developer ideas on 2016</a>
						<span class="date">February 14, 2015</span>
					</div>
				</li>
				<li>
					<div class="post-content">
						<a href="#">Crazy developer ideas on 2016</a>
						<span class="date">February 14, 2015</span>
					</div>
				</li>
				<li>
					<a href="#" class="post-image"><img src="assets/img/posts/post02.jpg" alt=""></a>
					<div class="post-content">
						<a href="#">Crazy developer ideas on 2016</a>
						<span class="date">February 14, 2015</span>
					</div>
				</li>
			</ul>
		</div>

		<!-- Contact -->
		<div class="latest-posts widget">
			<h6>Contact me</h6>
			<form id="contact-form-2" class="contact-form validate-form">
				<div class="form-group input-wrapper">
					<input type="text" class="form-control" required>
					<span class="input-label">Name</span>
				</div>
				<div class="form-group input-wrapper">
					<input type="email" class="form-control" required>
					<span class="input-label">E-mail</span>
				</div>
				<div class="form-group input-wrapper">
					<textarea name="message" cols="30" rows="4" class="form-control"></textarea>
					<span class="input-label">Message</span>
					<span class="input-line"></span>
				</div>
				<div class="row">
					<div class="col-sm-8 col-sm-push-2">
						<button type="submit" class="btn btn-submit"><span>Send message</span></button>
					</div>
				</div>
			</form>
		</div>
	</div>
</nav>
<!-- Panel / End -->

<!-- Ajax Modal -->
<div id="ajax-modal"></div>
<!-- Ajax Loader -->
<svg id="ajax-loader" class="loader" width="65px" height="65px" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg"><circle class="circle" fill="none" stroke-width="3" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg>

<!-- JS Libraries -->
<script src="assets/js/jquery-1.12.3.min.js"></script>

<!-- JS Plugins -->
<script src="assets/js/plugins.js"></script>

<!-- JS Core -->
<script src="assets/js/core.js"></script>

<!-- JS Google Map -->
<script src="http://maps.google.com/maps/api/js"></script>"index-pl.html"

</body>

</html>
